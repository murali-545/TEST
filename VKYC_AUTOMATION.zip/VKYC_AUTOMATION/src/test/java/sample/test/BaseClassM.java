package sample.test;

import java.awt.AWTException;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.bouncycastle.its.ITSPublicEncryptionKey.symmAlgorithm;

public class BaseClassM {
    public static void main(String[] args) throws InterruptedException, AWTException {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Select the option to run:");
            System.out.println("1. Add Customer");
            System.out.println("2. Add Customer with Aadhar");
            System.out.println("3. Add Complete Customer");
            System.out.println("4.Run The Live Agent and Customer Call");
            System.out.println("5. Exit");

            int choice = -1;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 5.");
                scanner.next(); // Clear the invalid input
                continue;
            }

            switch (choice) {
                case 1:
                    AddCustomer1.main(args);
                    break;
                case 2:
                    AddCustomer2.main(args);
                    break;
                case 3:
                    AddCustomer3.main(args);
                    break;
                case 4:
                    VKYC_LIVE_CALL.main(args);
                    break;

                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
