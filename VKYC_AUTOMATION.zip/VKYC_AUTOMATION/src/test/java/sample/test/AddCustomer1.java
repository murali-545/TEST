package sample.test;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AddCustomer1 
{
public static void main(String[] args) throws InterruptedException
{
	
	WebDriverManager.chromedriver().setup();
	WebDriver driver =new ChromeDriver();
	driver.manage().window().maximize();
	Thread.sleep(2000);
	driver.get("https://kycuat.transcorpint.com/user/");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@name=\"username\"]")).sendKeys("muralikrishna.m@m2pfintech.com");
	driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("Murali@93");
	Thread.sleep(2000);
	WebElement roleSelect = driver.findElement(By.xpath("//select[@name=\"rolename\"]"));
	Select s = new Select(roleSelect);
	s.selectByVisibleText("Agent");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
	Thread.sleep(2000);
	try {
	
	 // Wait for the button to be clickable and then click it
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    WebElement yesButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Yes']")));
	    yesButton.click();
	} catch (NoSuchElementException e) {
	    System.out.println("Element not found: " + e.getMessage());
	} catch (Exception e) {
	    System.out.println("An unexpected exception occurred: " + e.getMessage());
	}
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("//button[text()=' Add Customer']")).click();
	driver.findElement(By.className("add-new-customer-button")).click();
	
	//Adding Customer Details:
	driver.findElement(By.xpath("//input[@placeholder='Customer ID*']")).sendKeys("1919");
	driver.findElement(By.xpath("//input[@placeholder='Application ID']")).sendKeys("555");
	driver.findElement(By.xpath("//input[@placeholder='Application Type']")).sendKeys("666");
	driver.findElement(By.xpath("//input[@placeholder='First Name*']")).sendKeys("Murali");
	driver.findElement(By.xpath("//input[@placeholder='Last Name*']")).sendKeys("Krishna");
	driver.findElement(By.xpath("//input[@placeholder='Father Name*']")).sendKeys("M");
	driver.findElement(By.xpath("(//input[@content='Date of Birth*'])")).sendKeys("09-09-2000");
	Thread.sleep(1000);
	WebElement GenSele = driver.findElement(By.xpath("(//select[@id='inputGroupSelect01'])[2]"));
	Select gs = new Select(GenSele);
	gs.selectByVisibleText("M");
	
	driver.findElement(By.xpath("//input[@placeholder='Mobile Number*']")).sendKeys("9988899888");
	driver.findElement(By.xpath("//input[@placeholder='Current Address*']")).sendKeys("HYD");
	driver.findElement(By.xpath("//input[@placeholder='Permanent Address*']")).sendKeys("HYD");
	driver.findElement(By.xpath("//input[@placeholder='Email Address*']")).sendKeys("m@m.com");
	driver.findElement(By.xpath("//button[@type='submit']")).click();
	
	Thread.sleep(2000);


System.out.println("Success");
} }
