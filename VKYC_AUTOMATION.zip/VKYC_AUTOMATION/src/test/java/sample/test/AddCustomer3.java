package sample.test;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AddCustomer3 
{
public static void main(String[] args) throws InterruptedException
{
	
	WebDriverManager.chromedriver().setup();
	WebDriver driver =new ChromeDriver();
	driver.manage().window().maximize();
	Thread.sleep(2000);
	driver.get("https://kycuat.transcorpint.com/user/");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@name=\"username\"]")).sendKeys("muralikrishna.m@m2pfintech.com");
	driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("Murali@93");
	Thread.sleep(2000);
	WebElement roleSelect = driver.findElement(By.xpath("//select[@name=\"rolename\"]"));
	Select s = new Select(roleSelect);
	s.selectByVisibleText("Agent");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
	Thread.sleep(2000);
	try {
	
	 // Wait for the button to be clickable and then click it
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    WebElement yesButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Yes']")));
	    yesButton.click();
	} catch (NoSuchElementException e) {
	    System.out.println("Element not found: " + e.getMessage());
	} catch (Exception e) {
	    System.out.println("An unexpected exception occurred: " + e.getMessage());
	}
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("//button[text()=' Add Customer']")).click();
	driver.findElement(By.className("add-new-customer-button")).click();
	
	//Adding Customer Details:
	driver.findElement(By.xpath("//input[@placeholder='Customer ID*']")).sendKeys("1919");
	driver.findElement(By.xpath("//input[@placeholder='Application ID']")).sendKeys("555");
	driver.findElement(By.xpath("//input[@placeholder='Application Type']")).sendKeys("666");
	driver.findElement(By.xpath("//input[@placeholder='First Name*']")).sendKeys("Murali");
	driver.findElement(By.xpath("//input[@placeholder='Last Name*']")).sendKeys("Krishna");
	driver.findElement(By.xpath("//input[@placeholder='Father Name*']")).sendKeys("M");
	driver.findElement(By.xpath("(//input[@content='Date of Birth*'])")).sendKeys("09-09-2000");
	Thread.sleep(1000);
	WebElement GenSele = driver.findElement(By.xpath("(//select[@id='inputGroupSelect01'])[2]"));
	Select gs = new Select(GenSele);
	gs.selectByVisibleText("M");
	
	driver.findElement(By.xpath("//input[@placeholder='Mobile Number*']")).sendKeys("9988899888");
	driver.findElement(By.xpath("//input[@placeholder='Current Address*']")).sendKeys("HYD");
	driver.findElement(By.xpath("//input[@placeholder='Permanent Address*']")).sendKeys("HYD");
	driver.findElement(By.xpath("//input[@placeholder='Email Address*']")).sendKeys("m@m.com");
	
	//Proof of Aadhar Deatils 
	
	driver.findElement(By.xpath("//input[@id='adharCheck']")).click();
	
	WebElement MG = driver.findElement(By.xpath("(//select[@id='inputGroupSelect01'])[3]"));
	Select FT = new Select(MG);
	FT.selectByVisibleText("Online e-KYC");
	
	WebElement od = driver.findElement(By.xpath("(//select[@id='inputGroupSelect01'])[4]"));
	Select gd = new Select(od);
	gd.selectByVisibleText("Aadhaar");
	
	driver.findElement(By.xpath("//input[@placeholder='OVD ID*']")).sendKeys("566676668666");
	driver.findElement(By.xpath("(//input[@placeholder='First Name*'])[2]")).sendKeys("M");
	driver.findElement(By.xpath("(//input[@placeholder='Last Name'])[1]")).sendKeys("K");

	driver.findElement(By.xpath("(//input[@placeholder='Father Name*'])[2]")).sendKeys("MSN");
	
	WebElement GEN2 = driver.findElement(By.xpath("(//select[@id='inputGroupSelect01'])[5]"));
	Select gsm = new Select(GEN2);
	gsm.selectByVisibleText("M");
	
	driver.findElement(By.xpath("(//input[@content='Date of Birth*'])[2]")).sendKeys("08-09-2001");
	driver.findElement(By.xpath("(//input[@placeholder='Mobile Number*'])[2]")).sendKeys("9988899888");
	driver.findElement(By.xpath("(//input[@placeholder='Email Address*'])[2]")).sendKeys("k@k.com");
	driver.findElement(By.xpath("(//input[@placeholder='Current Address*'])[2]")).sendKeys("HYD");
	driver.findElement(By.xpath("(//label[text()='Attach photo*'])[1]")).click();
        Thread.sleep(3000);
	    StringSelection stringSelection = new StringSelection("C:\\Users\\VenkataMural_d3bsi9h\\Desktop\\M.jpg");
        
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
        Robot robot = null;
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
        robot.delay(500);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.delay(500);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.delay(500);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.delay(500);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.delay(500);
        robot.keyRelease(KeyEvent.VK_ENTER);
    
	Thread.sleep(5000);
	
	//Proof of PAN Deatils
	driver.findElement(By.xpath("//input[@id='pancheck']")).click();
	Thread.sleep(2000);
	WebElement MKM = driver.findElement(By.xpath("(//select[@id='inputGroupSelect01'])[6]"));
	Select GT = new Select(MKM);
	GT.selectByVisibleText("NSDL");
	
	driver.findElement(By.xpath("(//input[@placeholder='First Name*'])[3]")).sendKeys("M");
	driver.findElement(By.xpath("(//input[@placeholder='Last Name'])[2]")).sendKeys("K");
	driver.findElement(By.xpath("(//input[@placeholder='Father Name*'])[3]")).sendKeys("MSN");
	driver.findElement(By.xpath("(//input[@content='Date of Birth*'])[3]")).sendKeys("08-09-2001");
	driver.findElement(By.xpath("//input[@placeholder='PAN Number*']")).sendKeys("MKMKM9898M");
    
	driver.findElement(By.xpath("(//label[text()='Attach photo*'])[2]")).click();
    Thread.sleep(3000);
    StringSelection stringSelection2 = new StringSelection("C:\\Users\\VenkataMural_d3bsi9h\\Desktop\\M.jpg");
    
    Clipboard clipboard2 = Toolkit.getDefaultToolkit().getSystemClipboard();
    clipboard2.setContents(stringSelection2, null);
    Robot robot2 = null;
    try {
        robot2 = new Robot();
    } catch (AWTException e) {
        e.printStackTrace();
    }
    robot.delay(500);
    robot.keyPress(KeyEvent.VK_ENTER);
    robot.keyRelease(KeyEvent.VK_ENTER);
    robot.delay(500);
    robot.keyPress(KeyEvent.VK_CONTROL);
    robot.keyPress(KeyEvent.VK_V);
    robot.delay(500);
    robot.keyRelease(KeyEvent.VK_V);
    robot.keyRelease(KeyEvent.VK_CONTROL);
    robot.delay(500);
    robot.keyPress(KeyEvent.VK_ENTER);
    robot.delay(500);
    robot.keyRelease(KeyEvent.VK_ENTER);

Thread.sleep(2000);
//Final Create Buttion
	driver.findElement(By.xpath("//button[@type='submit']")).click();

System.out.println("Success");
} }
