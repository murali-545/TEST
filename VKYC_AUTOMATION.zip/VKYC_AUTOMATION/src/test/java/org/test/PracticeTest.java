package org.test;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PracticeTest 
{
public static void main(String[] args) throws InterruptedException
{
	
	WebDriverManager.chromedriver().setup();
	WebDriver driver =new ChromeDriver();
	driver.manage().window().maximize();
	Thread.sleep(2000);
	driver.get("https://kycuat.transcorpint.com/user/");
	Thread.sleep(4000);
	driver.findElement(By.xpath("//input[@name=\"username\"]")).sendKeys("muralikrishna.m@m2pfintech.com");
	driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("Murali@93");
	Thread.sleep(4000);
	WebElement roleSelect = driver.findElement(By.xpath("//select[@name=\"rolename\"]"));
	Select s = new Select(roleSelect);
	s.selectByVisibleText("Agent");
	Thread.sleep(4000);
	driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
	Thread.sleep(2000);
	

try {
    // Wait for the button to be clickable and then click it
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement yesButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Yes']")));
    yesButton.click();
} catch (NoSuchElementException e) {
    System.out.println("Element not found: " + e.getMessage());
} catch (Exception e) {
    System.out.println("An unexpected exception occurred: " + e.getMessage());
}

System.out.println("Success");
} }
