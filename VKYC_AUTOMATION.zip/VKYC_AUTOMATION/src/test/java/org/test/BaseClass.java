package org.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import org.openqa.selenium.By;
public class BaseClass {

	public static WebDriver driver;
	
		public static WebElement waitForElementVisibility(WebDriver driver, By locator, int timeoutInSeconds)
		{
		    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds));
		    return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		    
	  }
		public static void implicitWait(int min) {
	//		 WebDriver driver =new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(min));
		}
		
		public static void urlLaunch(String url) {
	        driver.get(url);
	    }
		// Method to send keys to an input element
	    public static void sendKeys(WebElement refName, String value) {
	    	refName.sendKeys(value);
	    }
	    public static void click(WebElement element) {
	        element.click();
	    }
	    public static void maximize() {
	    driver.manage().window().maximize();
	    }
	}
		


	

