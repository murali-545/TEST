package org.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Login 
{
public static void main(String[] args) throws InterruptedException
{
	//System.setProperty("webdriver.chrome.driver","C:\\Users\\VenkataMuraliKrishna\\eclipse-workspace\\TestDemo\\chromedriver.exe");
	WebDriverManager.chromedriver().setup();
//	ChromeOptions options=new ChromeOptions();
//	options.addArguments("--disable-notifications");
//	options.addArguments("use-fake-ui-for-media-stream");
	WebDriver driver =new ChromeDriver();
	driver.manage().window().maximize();
	Thread.sleep(2000);
	driver.get("https://kycuat.transcorpint.com/user/");
	
	
}	
  
}
