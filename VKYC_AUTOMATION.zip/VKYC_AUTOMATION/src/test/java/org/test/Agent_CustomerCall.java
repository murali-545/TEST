package org.test;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Agent_CustomerCall extends BaseClass
{
public static void main(String[] args) throws InterruptedException, AWTException
{
	//implicitWait(2);
	WebDriverManager.chromedriver().setup();
	ChromeOptions options = new ChromeOptions();
    options.addArguments("--disable-notifications");
    options.addArguments("--disable-popup-blocking"); 
    
    options.addArguments("use-fake-ui-for-media-stream"); // Use this to handle media stream (camera/microphone) popups
   // options.addArguments("use-fake-device-for-media-stream"); // Use this to handle media stream (camera/microphone) popups

    // Launch Chrome with the specified options
    WebDriver driver = new ChromeDriver(options);

  
	driver.manage().window().maximize();
	
	//Thread.sleep(2000);
	driver.get("https://kycuat.transcorpint.com/user/");
	//Thread.sleep(5000);
	
	driver.findElement(By.xpath("//input[@name=\"username\"]")).sendKeys("muralikrishna.m@m2pfintech.com");
	driver.findElement(By.xpath("//input[@name=\"password\"]")).sendKeys("Murali@93");
	Thread.sleep(2000);
	WebElement roleSelect = driver.findElement(By.xpath("//select[@name=\"rolename\"]"));
	Select s = new Select(roleSelect);
	s.selectByVisibleText("Agent");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
	Thread.sleep(2000);
	try {
	
	 // Wait for the button to be clickable and then click it
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    WebElement yesButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Yes']")));
	    yesButton.click();
	} catch (NoSuchElementException e) {
	    System.out.println("Element not found: " + e.getMessage());
	} catch (Exception e) {
	    System.out.println("An unexpected exception occurred: " + e.getMessage());
	}
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("//button[text()='Initiate call']")).click();
	Thread.sleep(20000);
    driver.findElement(By.xpath("//button[text()='Proceed']")).click();
    
    Thread.sleep(3000);
    Robot robot = new Robot();
   
    robot.delay(500);
    robot.keyPress(KeyEvent.VK_TAB);
    robot.keyRelease(KeyEvent.VK_TAB);
    robot.delay(500);
    robot.keyPress(KeyEvent.VK_RIGHT);
    robot.keyPress(KeyEvent.VK_RIGHT);
    robot.delay(500);
    robot.keyRelease(KeyEvent.VK_RIGHT);
    robot.keyRelease(KeyEvent.VK_RIGHT);
    robot.delay(500);
    robot.keyPress(KeyEvent.VK_TAB);
    robot.keyRelease(KeyEvent.VK_TAB);
    robot.delay(500);
    robot.keyPress(KeyEvent.VK_ENTER);
    robot.delay(500);
    robot.keyRelease(KeyEvent.VK_ENTER);
    
    
    driver.findElement(By.xpath("//button[text()='Ok']")).click();
    Thread.sleep(5000);
    //driver.findElement(By.xpath("//button[text()='Next']")).click();
    WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton1 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Next']")));
    
    Actions actions1 = new Actions(driver);
    actions1.moveToElement(NextButton1).click().perform();

    Thread.sleep(5000);
    //driver.findElement(By.xpath("//button[text()='Next']")).click();
    WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton2 = wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Next']")));
    
    Actions actions2 = new Actions(driver);
    actions2.moveToElement(NextButton2).click().perform();
    Thread.sleep(10000);
    driver.findElement(By.xpath("(//button[text()='Ask'])[1]")).click();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//button[@class='btn-round btn-green']")).click();
    Thread.sleep(5000);
    driver.findElement(By.xpath("(//button[text()='Ask'])[1]")).click();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//button[@class='btn-round btn-green']")).click();
    Thread.sleep(5000);
    //driver.findElement(By.xpath("//button[text()='Next']")).click();
    WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton3 = wait3.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Next']")));
    
    Actions actions3 = new Actions(driver);
    actions3.moveToElement(NextButton3).click().perform();
    Thread.sleep(5000);
   //driver.findElement(By.xpath("//button[text()='Capture']")).click();
    WebDriverWait wait8 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton8 = wait8.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Capture']")));
    
    Actions actions8 = new Actions(driver);
    actions8.moveToElement(NextButton8).click().perform();
    Thread.sleep(5000);
    driver.findElement(By.xpath("//button[text()='Check Liveness']")).click();
    Thread.sleep(5000);
    //driver.findElement(By.xpath("//button[text()='Next']")).click();
    WebDriverWait wait4 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton4 = wait4.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Next']")));
    
    Actions actions4 = new Actions(driver);
    actions4.moveToElement(NextButton4).click().perform();
    Thread.sleep(5000);
    //driver.findElement(By.xpath("//button[@class='btn-round btn-green']")).click();
    WebDriverWait wait9 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton9 = wait9.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn-round btn-green']")));
    
    Actions actions9 = new Actions(driver);
    actions9.moveToElement(NextButton9).click().perform();
    //driver.findElement(By.xpath("//button[text()='Next']")).click();
    WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton5 = wait5.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Next']")));
    
    Actions actions5 = new Actions(driver);
    actions5.moveToElement(NextButton5).click().perform();
    Thread.sleep(5000);
    //driver.findElement(By.xpath("//button[text()='Next']")).click();
  
    WebDriverWait wait6 = new WebDriverWait(driver, Duration.ofSeconds(20));
    WebElement NextButton6 = wait6.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn']")));
    
    Actions actions6 = new Actions(driver);
    actions6.moveToElement(NextButton6).click().perform();  
       
    Thread.sleep(5000);
    //driver.findElement(By.xpath("//button[@class='btn-round btn-green']")).click();
    WebDriverWait wait10 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton10 = wait10.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn-round btn-green']")));
    
    Actions actions10 = new Actions(driver);
    actions10.moveToElement(NextButton10).click().perform();
    //driver.findElement(By.xpath("//button[text()='Next']")).click();
    WebDriverWait wait7 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton7 = wait7.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Next']")));
    
    Actions actions7 = new Actions(driver);
    actions7.moveToElement(NextButton7).click().perform();
    Thread.sleep(10000);
    //driver.findElement(By.xpath("//button[text()='Capture PAN']")).click();
    WebDriverWait wait12 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton12 = wait12.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Capture PAN']")));
    
    Actions actions12 = new Actions(driver);
    actions12.moveToElement(NextButton12).click().perform();
    
    Thread.sleep(15000);
    driver.findElement(By.xpath("//button[text()='Capture']")).click();
    Thread.sleep(15000);
    driver.findElement(By.xpath("//button[text()='Confirm']")).click();
    Thread.sleep(15000);
    driver.findElement(By.xpath("//button[text()='End Call']")).click();
    Thread.sleep(5000);
    WebDriverWait wait11 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton11 = wait11.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn-round btn-green']")));
    
    Actions actions11 = new Actions(driver);
    actions11.moveToElement(NextButton11).click().perform();
    
    Thread.sleep(5000);
    driver.findElement(By.xpath("//label[text()='Your VKYC is approved as per process']")).click();
    Thread.sleep(5000);
    driver.findElement(By.xpath("(//button[text()='Submit'])[2]")).click();
    Thread.sleep(5000);
    //driver.findElement(By.xpath("(//button[text()='Submit'])[1]")).click();
    WebDriverWait wait13 = new WebDriverWait(driver, Duration.ofSeconds(10));
    WebElement NextButton13 = wait13.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()='Submit'])[1]")));
    
    Actions actions13 = new Actions(driver);
    actions13.moveToElement(NextButton13).click().perform();
    System.out.println("Success");
} }
