package org.test;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddCustomerPojo extends BaseClass
{
public AddCustomerPojo()
{
	PageFactory.initElements(driver, this);
}
@FindBy (xpath="//input[@name=\"username\"]")
private WebElement username;

@FindBy (xpath="//input[@name=\"password\"]")
private WebElement password;

@FindBy(xpath="//select[@name=\"rolename\"]")
private WebElement roleName;

@FindBy(xpath="//button[@type=\"submit\"]")
private WebElement submitBtn;

public WebElement getUsername() {
	return username;
}

public WebElement getPassword() {
	return password;
}

public WebElement getRoleName() {
	return roleName;
}

public WebElement getSubmitBtn() {
	return submitBtn;
}


}


