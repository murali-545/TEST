package Demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login 
{
public static void main(String[] args) 
{
	System.setProperty("webdriver.chrome.driver","C:\\Users\\VenkataMural_d3bsi9h\\Downloads\\chromedriver-win32\\chromedriver.exe" );
	
	WebDriver driver = new ChromeDriver();
	driver.get("http://www.google.com");
}
}
