package Test_M;

public class HelloM
{
public static void main(String []args)
{
System.out.println("Hello Murali");	
}
}