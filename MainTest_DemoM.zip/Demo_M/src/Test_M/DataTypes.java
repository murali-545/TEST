package Test_M;

public class DataTypes {
	public static void main(String []args)
	{
		
		int number = 10;
		double decimal=5.5;
		char charcter = 'M';
		boolean isJavaFun = true;
		
		System.out.println("Number :" + number);
		System.out.println("Decimal :" +decimal);
		System.out.println("Character :" + charcter);
		System.out.println("isJavaFun :" +isJavaFun);
	}

	
}
