package Test_M;

public class ControlFlow {
    public static void main(String[] args) {
        int number = 10;

        if (number > 0) {
            System.out.println("Positive number");
        } else if (number < 0) {
            System.out.println("Negative number");
        } else {
            System.out.println("Zero");
        }

        for (int i = 0; i < 5 ; i++) {
            System.out.println("i: " + i);
        }
    }
}
