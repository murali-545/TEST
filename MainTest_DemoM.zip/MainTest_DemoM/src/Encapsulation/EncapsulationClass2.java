package Encapsulation;

public class EncapsulationClass2 {
	  public static void main(String[] args) {
	    EncapsulationClass myObj = new EncapsulationClass();
	    
	    myObj.setName("John");  // error
	    System.out.println(myObj.getName()); // error 
	  }
	}