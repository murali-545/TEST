package Encapsulation;

public class EncapsulationClass 
{
   private String name;  // private = restricted access

   public String getName() 
   {
	return name;
  }

public void setName(String name) 
{
	this.name = name;
}
   

		 		  
	
		
}
