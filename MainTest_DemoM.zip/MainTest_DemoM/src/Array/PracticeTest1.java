package Array;



import java.util.ArrayList;
import java.util.Iterator;

class PracticeTest2 {
    int rollno;
    String name;
    int age;

    PracticeTest2(int rollno, String name, int age) {
        this.rollno = rollno;
        this.name = name;
        this.age = age;
    }
}

public class PracticeTest1 {

    public static void main(String args[]) {
        // Creating user-defined class objects
        PracticeTest2 s1 = new PracticeTest2(101, "Sonoo", 23);
        PracticeTest2 s2 = new PracticeTest2(102, "Ravi", 21);
        PracticeTest2 s3 = new PracticeTest2(103, "Hanumat", 25);
        
        // creating arraylist
        ArrayList<PracticeTest2> al = new ArrayList<PracticeTest2>();
        al.add(s1); // adding PracticeTest2 class object
        al.add(s2);
        al.add(s3);
        
        // Getting Iterator
        Iterator<PracticeTest2> itr = al.iterator();
        
        // traversing elements of ArrayList object
        while (itr.hasNext()) {
            PracticeTest2 st = itr.next();
            System.out.println(st.rollno + " " + st.name + " " + st.age);
        }
    }
}
