package Array;

public class EnhancedForLoopM 
{
  
 public static void main(String[] args) 
{
	 //Enhanced or For Each For Loop //Array allow duplicate values
	 int a[] = {1,2,3,4,5,5,4};
	 for(int b : a)
	 {
		 System.out.println(b);
	 }
	 
	 ///Normal  For Loop
	 int d[] = new int[5];
	     d[0]= 4;
	     d[1]= 4;
	     d[2]= 6;
	     d[3]= 7;
	     d[4]= 8;
	     for(int i=0;i<d.length;i++)//length is the property of array  
	     System.out.println(d[i]);  
}
}

