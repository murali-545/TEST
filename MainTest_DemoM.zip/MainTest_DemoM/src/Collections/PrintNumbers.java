package Collections;

import java.util.ArrayList;
import java.util.List;

public class PrintNumbers {
    public static void main(String[] args) {
    	
        // Create a list to store numbers
        List<Integer> numbers = new ArrayList<>();
        
        // Add numbers from 1 to 100 to the list
        for (int i = 1; i <= 100; i++) {
        	
            if (i != 5 && i != 50 && i != 55)
            {
            	
                numbers.add(i);
            }
        }
        
        // Print the numbers, skipping 5, 50, and 55
        for (int number : numbers) {
            System.out.println(number);
        }
    }
}
