package Collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListAL 
{
	public static void main(String[] args) 
	{
		 List<Object> al=new ArrayList<Object>();//creating arraylist    
		  al.add("Ravi");//adding object in arraylist    
		  al.add("Vijay");    
		  al.add("Ravi");    
		  al.add("Ajay");    
		  al.add(1); 
		  al.add(200l);
		  
		  List<String> al2=new LinkedList<String>();//creating linkedlist    
		  al2.add("James");//adding object in linkedlist    
		  al2.add("Serena");    
		  al2.add("Swati");    
		  al2.add("Junaid");    
		    
		  System.out.println("arraylist: "+al);  
		  System.out.println("linkedlist: "+al2);  
		
	}

}
