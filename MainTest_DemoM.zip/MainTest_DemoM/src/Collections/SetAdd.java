package Collections;

import java.io.*;   
import java.util.*;   
public class SetAdd {   
    public static void main(String args[])   
    {   
        Set<Integer> data = new LinkedHashSet<Integer>();   
        data.add(31);   
        data.add(21);   
        data.add(41);   
        data.add(11);   
        data.add(61);   
        data.add(51);   
        System.out.println("data: " + data);   
    }   
}  


//The add() method insert a new value to the set. The method returns true and 
//false depending on the presence of the insertion element. It returns false if 
//the element is already present in the set and returns true if it is not present in the set.