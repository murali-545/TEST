package ObjectInitialization;

class Dog {
    String name;
    int age;
    
    // Constructor to initialize object
    Dog(String n, int a) {
        name = n;
        age = a;
    }
    
    // Method to initialize object
    void setDetails(String n, int a) {
        name = n;
        age = a;
    }
    
    public static void main(String[] args) {
        // Initializing object by reference variable
        Dog dog1 = new Dog("Unnamed", 0);
        dog1.name = "Buddy";
        dog1.age = 3;
        System.out.println("Dog1's name: " + dog1.name);
        System.out.println("Dog1's age: " + dog1.age);
        
        // Initializing object by method
        Dog dog2 = new Dog("Unnamed", 0);
        dog2.setDetails("Charlie", 4);
        System.out.println("Dog2's name: " + dog2.name);
        System.out.println("Dog2's age: " + dog2.age);
        
        // Initializing object by constructor
        Dog dog3 = new Dog("Max", 5);
        System.out.println("Dog3's name: " + dog3.name);
        System.out.println("Dog3's age: " + dog3.age);
    }
}
