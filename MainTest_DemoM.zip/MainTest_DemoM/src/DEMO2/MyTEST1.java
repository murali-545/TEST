package DEMO2;

public class MyTEST1 
{
public void mytest()
{
	System.out.println("importing from different pacakage");
}
}
