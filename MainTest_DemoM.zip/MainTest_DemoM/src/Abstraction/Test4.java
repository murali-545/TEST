package Abstraction;

public class Test4 implements SampleIntface
{

	@Override
	public void m1() 
	{
		System.out.println("From Interface");
	}

	public static void main(String[] args) 
	{
		Test4 t = new Test4();
		t.m1();
		SampleIntface.m2();
	}
}
