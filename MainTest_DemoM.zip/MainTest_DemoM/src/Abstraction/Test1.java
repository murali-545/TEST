package Abstraction;

public class Test1 extends AbstractClass1 
{

	@Override //added unimpleted method
	public void test2() 
	{
		
		System.out.println("Overrided Abstarct Method");
	}
	
	public void m1() 
	{
		System.out.println("interface");
	}
	public static void main(String[] args) 
	{
		Test1 t = new Test1();
		t.test1();
		t.test2();
	}

	

}
