package Abstraction;

public abstract class AbstractClass1 implements SampleIntface
{
public void test1()
{
	System.out.println("Non abstarct method");
}
public abstract void test2();

}
