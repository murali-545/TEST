package Abstraction;

public interface SampleIntface 
{

	public void m1(); //idhi abstarct method,normal metod with out business logic,interface converted to abstarct method
	
	public static void m2()
	{
		System.out.println("Static method interface"); //Static method we can write in interface
	}      //We can declare static method but it is not usefull

	
	}

