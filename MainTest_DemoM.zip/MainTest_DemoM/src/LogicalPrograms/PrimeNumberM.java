package LogicalPrograms;


public class PrimeNumberM 
{
public static void main(String[] args) 
{
	int count;
	int number=10;
	for(int i=1; i<=number; i++) // i=1;1<=10; //i=1+1;2<=10 //i=2+1; 3<=10 //i=3+1; 4<=10 //i=4+1; 5<=10 //i=5+1; 6<=10
	{
	    count=0; 
	
	   for (int j = 2; j <= i/2; j++)  //j=2; 2<=1/2; //j=2; 2<=2/2 //j=2; 2<=3/2 //j=2;2<=4/2 //j=2; 2<=5/2// j=2;2<=6/2
	{
		if(i%j==0) //4%2==0 and 2 next 2%2==0
		{
			count ++; //count = 0+1
			break;
		}
	}
	   if(count==0) // 1==0
		{
			System.out.println("Primie Number"+ i); //i=1,//i=2,//i=3;//i=5
		} 
	}
	
}
}
