package LogicalPrograms;

import java.util.Scanner;

public class LeapYearExceptionEndling {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        try {
            // Prompt the user to enter a year
            System.out.println("Please Enter a Year:");
            int year = sc.nextInt();

            // Check if the year is a leap year
            if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
                System.out.println(year + " is a leap year.");
            } else {
                System.out.println(year + " is not a leap year.");
            }
        } 
        catch (Exception e) {
            // Handle any exceptions (such as input mismatch)
            System.out.println("Invalid input. Please enter a valid integer.");
        } finally {
            // Close the scanner to free up resources
            sc.close();
        }
    }
}



//package LogicalPrograms;

//
//
//import java.util.InputMismatchException;
//import java.util.Scanner;
//
//public class LeapYearExceptionEndling {
//
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        int year = 0;
//
//        try {
//            System.out.println("Please Enter a Number:");
//            year = sc.nextInt();
//        } catch (InputMismatchException e) {
//            System.out.println("Invalid input. Please enter a valid number.");
//            sc.next(); // Clear the invalid input
//            return; // Exit the program or handle as needed
//        }
//
//        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
//            System.out.println(year + " is a leap year.");
//        } else {
//            System.out.println(year + " is not a leap year.");
//        }
//
//        sc.close(); // Close the scanner
//    }
//}

//OR

//package LogicalPrograms;
//import java.util.InputMismatchException;
//import java.util.Scanner;
//public class LeapYearExceptionEndling {
//  public static void main(String[] args) {     
//    	Scanner sc = new Scanner(System.in);
//    	int year = 0;   	
//    	try {
//        	
//    		 System.out.println("Please Enter a Number:");
//    		 year=sc.nextInt();
//            
//            if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
//                System.out.println(year + " is a leap year.");
//            } else {
//                System.out.println(year + " is not a leap year.");
//        } 
//        }catch (InputMismatchException e) {
//            System.out.println("Invalid input. Please enter a valid number.");
//            sc.next(); // Clear the invalid input
//            return; // Exit the program or handle as needed      
//        }
//    	sc.close();       
//        }
//         // Close the scanner
//    }
//





