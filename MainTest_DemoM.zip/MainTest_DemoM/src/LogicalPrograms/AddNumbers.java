package LogicalPrograms;

public class AddNumbers {
    public static void main(String[] args) {
        int a = 20;
        int b = 10;
        int c = a + b;

        System.out.println("The sum of two numbers is:" +c);
    }
}
