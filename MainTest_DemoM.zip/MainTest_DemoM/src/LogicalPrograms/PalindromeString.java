package LogicalPrograms;

public class PalindromeString {
    public static void main(String[] args) {
        String s = "MADAM";
        String mk = new StringBuffer(s).reverse().toString();

        if (s.equals(mk))
        {
            System.out.println(mk + " is a palindrome.");
        } else {
            System.out.println(mk + " is not a palindrome.");
        }
    }
}
