package LogicalPrograms;

import java.util.Scanner;

public class LeapYear {

    public static void main(String[] args) {
        //int year = 2024;  // Change this to test different years
    	
        Scanner sc=new Scanner(System.in);
        System.out.println("Please Enter a Number");
        int year =sc.nextInt();
        
        if((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
        {
        	System.out.println("Is leap Year"+year);
        }
        else
        {
        	System.out.println("Is not leap Year"+year);
        }
           }
}
 