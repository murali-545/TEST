package LogicalPrograms;

public class Fibanacci {

    public static void main(String[] args) {
        int n = 10; // Number of terms in the Fibonacci series
        int num1 = 0;
        int num2 = 1;

        System.out.println("Fibonacci Series up to terms:" +n);

        for (int i = 1; i <= n; ++i) {
            System.out.print(num1 + " ");

            // Compute the next term
            int num3 = num1 + num2;
            num1 = num2;
            num2 = num3;
        }
    }
}
