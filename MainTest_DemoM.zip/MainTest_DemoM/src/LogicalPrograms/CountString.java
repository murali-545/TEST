package LogicalPrograms;

public class CountString {
    public static void main(String[] args) {
        String a = "Apple";
        int countA = 0, countP = 0, countL = 0, countE = 0;
        
        // Convert the string to lowercase to handle case-insensitivity
        String s = a.toLowerCase();

        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case 'a':
                    countA++;
                    break;
                case 'p':
                    countP++;
                    break;
                case 'l':
                    countL++;
                    break;
                case 'e':
                    countE++;
                    break;
                default:
                    // Do nothing for other characters
                    break;
            }
        }

        // Printing the results
        System.out.println("Number of 'A's: " + countA);
        System.out.println("Number of 'p's: " + countP);
        System.out.println("Number of 'l's: " + countL);
        System.out.println("Number of 'e's: " + countE);
    }
}

