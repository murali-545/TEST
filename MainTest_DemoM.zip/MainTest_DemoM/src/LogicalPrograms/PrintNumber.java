package LogicalPrograms;

public class PrintNumber {
    public static void main(String[] args) {
        // Loop from 1 to 100
        for (int i = 1; i <= 100; i++) {
            // Check if the number is 5, 50, or 55, if so, skip it
            if (i == 5 || i == 50 || i == 55) {
                continue; // Skip the rest of the loop body and move to the next iteration
            }
            // Print the number
            System.out.println(i);
        }
    }
}
