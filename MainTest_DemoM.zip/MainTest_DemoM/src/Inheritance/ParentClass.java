package Inheritance;

public class ParentClass extends ParentClass2
{
public void cars()
{
	System.out.println("Ford,BMW,Volvo,Nexon");
}
}
