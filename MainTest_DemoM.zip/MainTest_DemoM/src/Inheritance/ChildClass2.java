package Inheritance;

public class ChildClass2 extends ParentClass
{
public static void main (String []args)
{
	ChildClass2 cdm = new ChildClass2();
	cdm.cars();

}
}
