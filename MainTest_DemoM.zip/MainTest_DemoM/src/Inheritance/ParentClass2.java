package Inheritance;

public class ParentClass2 
{
public void fruits()
{
	System.out.println("Apple,Banaa,Guva,Orange");
}


}
