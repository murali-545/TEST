package Inheritance;

public class ChildClass extends ParentClass  
{
	public static void main(String []args)
	{
		ChildClass cm= new ChildClass();
		cm.cars();
		cm.fruits();
	
	}
	
	
}
