package Strings;

public class StartsWithM {
	  public static void main(String[] args) {
	    String myStr = "Hello";
	    System.out.println(myStr.startsWith("Hel"));
	    System.out.println(myStr.startsWith("llo"));
	    System.out.println(myStr.startsWith("o"));
	  }
	}


//The startsWith() method checks whether a string starts with the specified character(s).
//
//Tip: Use the endsWith() method to check whether a string ends with the specified character(s).

