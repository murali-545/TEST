package Strings;

public class ContainsM {
	  public static void main(String[] args) {
	    String myStr = "Hello";
	    System.out.println(myStr.contains("Hel"));
	    System.out.println(myStr.contains("e"));
	    System.out.println(myStr.contains("Hi"));
	  }
	}

//The contains() method checks whether a string contains a sequence of characters.
//
//Returns true if the characters exist and false if not.