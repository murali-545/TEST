package Strings;

public class GetBytesM {
	  public static void main(String[] args) {
	    String myStr = "Hello";
	    byte[] result = myStr.getBytes();
	    System.out.println(result[0]);
	  }
	}
//The getBytes() method converts a string into an array of bytes.
//
//The encoding of the bytes depends on the charset argument.
//
//If the charset argument is not provided then the bytes will be encoded using the system's default character set.