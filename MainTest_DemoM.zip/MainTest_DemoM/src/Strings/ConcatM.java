package Strings;

public class ConcatM 
{
	public static void main(String[] args) {
	    String firstName = "John ";
	    String lastName = "Doe";
	    System.out.println(firstName.concat(lastName));
	  }
}

//The concat() method appends (concatenate) a string to the end of another string.