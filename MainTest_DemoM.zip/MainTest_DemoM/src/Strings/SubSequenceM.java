package Strings;
public class SubSequenceM {
	  public static void main(String[] args) {
	    String myStr = "Hello, World!";
	    System.out.println(myStr.subSequence(7, 12));
	  }
	}


//The subSequence() method returns a subsequence from the string as a CharSequence object.