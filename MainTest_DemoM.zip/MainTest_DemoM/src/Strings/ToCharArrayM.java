package Strings;


public class ToCharArrayM {
	  public static void main(String[] args) {
	    String myStr = "Hello";
	    char[] myArray = myStr.toCharArray();
	    System.out.println(myArray[4]);
	  }
	}

//The toCharArray() method returns a new char array representing the contents of the string.


