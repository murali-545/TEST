package Strings;

public class CodePointAtM {
	  public static void main(String[] args) {
	    String myStr = "Hello";
	    int result = myStr.codePointAt(1);
	    System.out.println(result);
	  }
	}

//The codePointAt() method returns the Unicode value of the character at the specified index in a string.
//The index of the first character is 0, the second character is 1, and so on
