package Strings;

public class CompareToM {
	  public static void main(String[] args) {
	    String myStr1 = "Hello";
	    String myStr2 = "Hello";
	    System.out.println(myStr1.compareTo(myStr2)); // Returns 0 because they are equal
	  }
	}

//The compareTo() method compares two strings lexicographically.
//
//The comparison is based on the Unicode value of each character in the strings.
//
//The method returns 0 if the string is equal to the other string. A value less than 0 is returned if the string is less than the other string (less characters) and a value greater than 0 if the string is greater than the other string (more characters).
//
//Tip: Use compareToIgnoreCase() to compare two strings lexicographyically, ignoring lower case and upper case differences.
//
//Tip: Use the equals() method to compare two strings without consideration of Unicode values.

