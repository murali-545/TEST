package Strings;

public class ReplaceM {
	  public static void main(String[] args) {
	    String myStr = "Hello";
	    System.out.println(myStr.replace('o', 'p'));
	  }
	}

//The replace() method searches a string for a specified character, and returns a new string where 
//the specified character(s) are replaced.

