package Strings;

public class ReplaceFirstM {
	  public static void main(String[] args) {
	    String myStr = "This is W3Schools";
	    String regex = "is";
	    System.out.println(myStr.replaceFirst(regex, "at"));
	  }
	}

//The replaceFirst() method replaces the first match of a regular expression in a string with a new substring.
//Replacement strings may contain a backreference in the form $n where n is the index of a group in the pattern.
//In the returned string, instances of $n will be replaced with the substring that was matched by the group or, 
//if $0 is used, by the whole expression. 
