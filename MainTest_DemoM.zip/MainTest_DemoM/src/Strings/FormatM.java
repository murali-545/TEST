package Strings;

public class FormatM {
	  public static void main(String[] args) {
	    String myStr = "Hello %s! One kilobyte is %,d bytes.";
	    String result = String.format(myStr, "World", 1024);
	    System.out.println(result);
	  }
	}

//The format() method returns a formatted string using a locale, format and additional arguments.
//
//If a locale is not passed to this method then the locale given by Locale.getDefault() is used.
//
//Data from the additional arguments is formatted and written into placeholders in the format string, 
//which are marked by a % symbol. The way in which arguments are formatted depends on the sequence of 
//characters that follows the % symbol.