package Strings;

public class IndexOfM {
	  public static void main(String[] args) {
	    String myStr = "Hello planet earth, you are a great planet.";
	    System.out.println(myStr.indexOf("planet"));
	  }
	}
//The indexOf() method returns the position of the first occurrence of specified character(s) in a string.
//
//Tip: Use the lastIndexOf method to return the position of the last occurrence of specified character(s) in a string.

