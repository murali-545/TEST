package Strings;

public class TrimM {
	  public static void main(String[] args) {
	    String myStr = "       Hello World!        ";
	    System.out.println(myStr);
	    System.out.println(myStr.trim());
	  }
	}

//The trim() method removes whitespace from both ends of a string.
//
//Note: This method does not change the original string.