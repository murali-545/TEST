package Strings;

public class SubStringM {
	  public static void main(String[] args) {
	    String myStr = "Hello, World!";
	    System.out.println(myStr.substring(7, 12));
	  }
	}

//The substring() method returns a substring from the string.
//
//If the end argument is not specified then the substring will end at the end of the string.


