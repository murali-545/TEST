package Strings;

public class SplitM {
	  public static void main(String[] args) {
	    String myStr = "Split a string by spaces, and also punctuation.";
	    String regex = "[,\\.\\s]";
	    String[] myArray = myStr.split(regex);
	    for (String s : myArray) {
		    System.out.println(s);
	    }
	  }
	}

//The split() method splits a string into an array of substrings using a regular expression as the separator.
//
//If a limit is specified, the returned array will not be longer than the limit. The last element of the array
//will contain the remainder of the string, which may still have separators in it if the limit was reached.