package Strings;

public class ToLowerCaseM {
	  public static void main(String[] args) {
	    String txt = "Hello World";
	    System.out.println(txt.toUpperCase());
	    System.out.println(txt.toLowerCase());
	  }
	}

//The toLowerCase() method converts a string to lower case letters.