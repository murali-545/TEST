package Strings;

public class ReplaceAllM {
	  public static void main(String[] args) {
	    String myStr = "I love cats. Cats are very easy to love. Cats are very popular.";
	    String regex = "(?i)cat";
	    System.out.println(myStr.replaceAll(regex, "dog"));
	  }
	}

//The replaceAll() method replaces the first match of a regular expression in a string with a new substring.
//
//Replacement strings may contain a backreference in the form $n where n is the index of a group in the pattern. 
//In the returned string, instances of $n will be replaced with the substring that was matched by the group or, 
//if $0 is used, by the whole expression. See "More Examples" below for an example of using a backreference.