package Strings;

public class ToUpperCaseM {
	  public static void main(String[] args) {
	    String txt = "Hello World";
	    System.out.println(txt.toUpperCase());
	    System.out.println(txt.toLowerCase());
	  }
	}

//The toUpperCase() method converts a string to upper case letters.