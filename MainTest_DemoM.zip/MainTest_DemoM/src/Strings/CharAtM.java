package Strings;

//The charAt() method returns the character at the specified index in a string.
//The index of the first character is 0, the second character is 1, and so on.
public class CharAtM 
{
public static void main(String[] args) 
{
	String myStr = "Hello";
	char result = myStr.charAt(4);
	System.out.println(result);
}
} //

//Excepton Handling

//package Strings;
//
//public class CharAtM {
//    public static void main(String[] args) {
//        String myStr = "Hello";
//        try {
//            char result = myStr.charAt(6);
//            System.out.println(result);
//        } catch (StringIndexOutOfBoundsException e) {
//            System.out.println("Index out of bounds. Please enter a valid index.");
//        }
//    }
//}
