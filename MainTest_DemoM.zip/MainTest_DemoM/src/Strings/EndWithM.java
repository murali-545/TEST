package Strings;

public class EndWithM {
	  public static void main(String[] args) {
	    String myStr = "Hello";
	    System.out.println(myStr.endsWith("Hel"));
	    System.out.println(myStr.endsWith("llo"));
	    System.out.println(myStr.endsWith("o"));
	  }
	}
//The endsWith() method checks whether a string ends with the specified character(s).
//Tip: Use the startsWith() method to check whether a string starts with the specified character(s).