package Strings;

public class LastIndexOf {
	  public static void main(String[] args) {
	    String myStr = "Hello planet earth, you are a great planet.";
	    System.out.println(myStr.lastIndexOf("planet"));
	  }
	}

//The lastIndexOf() method returns the position of the last occurrence of specified character(s) in a string.
//
//Tip: Use the indexOf method to return the position of the first occurrence of specified character(s) in a string.