package Strings;

public class JoinM {
	  public static void main(String[] args) {
	    String fruits = String.join(" ", "Orange", "Apple", "Mango");
	    System.out.println(fruits);
	  }
	}

//The join() method joins one or more strings with a specified separator.