package Strings;

public class LengthM {
	  public static void main(String[] args) {
	    String txt = "MURALI";
	    System.out.println(txt.length());
	  }
	}

//The length() method returns the length of a specified string.
//
//Note: The length of an empty string is 0.