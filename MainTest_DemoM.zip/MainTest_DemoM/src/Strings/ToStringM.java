package Strings;

public class ToStringM {
	  public static void main(String[] args) {
	    String myStr = "Hello, World!";
	    System.out.println(myStr.toString());
	  }
	}

//The toString() method returns the string itself.
//
//This method may seem redundant, but its purpose is to allow code that is treating the string as a more 
//generalized object to know its string value without casting it to String type.