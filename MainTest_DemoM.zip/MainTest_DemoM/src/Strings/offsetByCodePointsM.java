package Strings;

public class offsetByCodePointsM {
	  public static void main(String[] args) {
	    String myStr = "Hello, World!";
	    int result = myStr.offsetByCodePoints(3, 2);
	    System.out.println(result);
	  }
	}

//he offsetByCodePoints() method returns an index in a string which is offset from another index by a specified number of code points.
//
//Note: A code point may be formed by more than one character. These code points will offset the index by more than 1.