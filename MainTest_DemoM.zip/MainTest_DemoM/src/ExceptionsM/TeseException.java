package ExceptionsM;

public class TeseException {
 
	
	public static void main(String[] args) 
	{
		int age=20;
		try
		{
			if(age<21)
			System.out.println("you are not eligible for marriage");
			throw new YourNotEligibleForMarriage();
			
		}
        catch(YourNotEligibleForMarriage y)
{
	
	System.out.println(y.getMessage());
}
	}

}
