package ExceptionsM;

public class YourNotEligibleForMarriage extends Exception
{
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		
		String s="you are not eligible for marriage and you are age below 21";
		return s;
		
	}

}
