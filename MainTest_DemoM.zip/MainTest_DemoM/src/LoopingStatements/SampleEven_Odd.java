package LoopingStatements;

public class SampleEven_Odd 
{
	
	public static void main(String[] args) 
	{
		
		for(int i=1; i<=10 ;i++)
		{
			if(i%2==0) //Evern Number and if(i%2!=0)--Odd Number
			{
				System.out.println("Even Number:" +i);
			}
			else
			{
				System.out.println("Odd Number" +i);
			}
			
		}
	
	}
}