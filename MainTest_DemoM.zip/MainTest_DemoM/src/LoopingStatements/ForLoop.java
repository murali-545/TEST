package LoopingStatements;

public class ForLoop 
{
public static void main(String[] args) 
{
	
	for(int i=1; i<=20 ;i++)
	{
		if(i%2==0) //Evern Number and if(i%2!=0)--Odd Number
		{
			System.out.println("Even Number:" +i);
		}
		
		
	}
	
}
}
