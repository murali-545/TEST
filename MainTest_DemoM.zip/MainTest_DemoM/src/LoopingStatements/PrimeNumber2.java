package LoopingStatements;

public class PrimeNumber2 {
    
    // Method to check if a number is prime
    public static boolean isPrime(int num) {
        // Corner case
        if (num <= 1) {
            return false;
        }
        
        // Check divisibility from 2 to num-1
        for (int i = 2; i < num; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        
        return true;
    }
    
    public static void main(String[] args) {
        int number = 30; // You can change this number to test other numbers
        
        if (isPrime(number)) {
            System.out.println(" The given number is a prime number." + number );
        } else {
            System.out.println(" The given number is a not a prime number." + number);
        }
    }
}
