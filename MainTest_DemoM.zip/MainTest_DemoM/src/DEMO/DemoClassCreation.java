package DEMO;

import DEMO2.MyTEST1;

public class DemoClassCreation 
{
public void test()
{
	System.out.println("Class Creation");
}
public static void main(String []args)
{
	
DemoClassCreation D= new DemoClassCreation();
DemoClassCreation2 M = new DemoClassCreation2();
MyTEST1 MJ =new MyTEST1();
 D.test();
 M.test2();
 MJ.mytest();
 
}

}
