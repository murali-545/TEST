package DEMO;

public class NestedIFTest 
{
public static void main(String []args)
{
	
int age= 18;
int llrdate =30;

if(age>=18 && age<=60)
{
System.out.println("You are eligible for LLR :" +age);	

if(llrdate>=30 && llrdate<=180)
{
	System.out.println("You are eligible for attend driving Test :" +llrdate);	

}
else if(llrdate<30)
{
	System.out.println("You are not eligible for attend driving Test :" +llrdate);	

}
else
{
	System.out.println("You are LLR date is expired:" +llrdate);	
}
}
else 
{
	System.out.println("You are not eligible to apply the license");
	}
}
}
