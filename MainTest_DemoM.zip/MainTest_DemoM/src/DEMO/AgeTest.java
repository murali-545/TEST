package DEMO;

import java.util.Scanner;

public class AgeTest 
{
public static void main(String []args)
{
	Scanner sc =new Scanner(System.in);
	System.out.println("Please Enter Number");
	int age = sc.nextInt();
	
	if(age>=18)
	{
		System.out.println("You are eligible");
	}
	else 
	{
		System.out.println("You are not eligible");

	}
}
}

//Other Format
//public static void main(String []args)
//{
//	 int age=18;
//	 
//	 if(age>=18)
//	 {
//		 System.out.println("You are eligible :" +age);
//	 }
//	 else
//	 {
//		 System.out.println("You are not eligible :" +age);
//	 }