package DEMO;

public class SampleTEST {
	public static void main(String[] args) 
	{
		System.out.println("Hello Murali");
	}
}
