package DEMO;

import java.util.Scanner;

public class DrivingLicence 
{
 public static void main(String []args)
 {
	 //int age=18;
	 //(Direct Diclaration Input)
	 
//	 OR(Manual Runtime Inputs)
	 
	    Scanner sc =new Scanner(System.in);
		System.out.println("Please Enter Number");
		int age = sc.nextInt();
		
//	 Int = Data Type, Age=Variable Name, After = all are values
// How to declare the varibale in JAVA?it is posible to direct declaration varible value-ANSWER 
//		is Direct declaration is not posible in java,we delacare the varibale syntax is data type variable name= value
		
	
	 
	 if(age>=18 && age<=21)
	 {
		 System.out.println("You are eligible for batch licence :" +age);
	 }
	 else if(age>21 && age<=60)
		 
	 {
		 System.out.println("You are eligible for batch and heavy licence :" +age);
	 }
	 
	 else
	 {
		 System.out.println("You are not eliGible for licence :" +age);
	 }
	 
 }
}

//Else IF(else if only one time) or Ladder IF(else if mutiple times)(Both are same)
