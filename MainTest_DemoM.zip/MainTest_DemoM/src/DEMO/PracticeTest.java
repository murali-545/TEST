package DEMO;

import java.util.Scanner;

public class PracticeTest 

//Satisfy three conditios
{
	public static void main (String[] args)
	{
		
		int age= 17;
		int date =30;
		
		if(age>=18 && age<=60)
		{
			System.out.println(" You are selected for LLR Tes:" +age);
			
			if(date>=30 && date<=180)
			{
				System.out.println(" You are selected for LLR Driving TEST:" +date);
			}
			else if(date<30)
			{
				System.out.println(" You are not eligible for LLR Test:" +date);
			}
			else
			{
				System.out.println(" You are not qualifie for LLR Test:" +date);

			}
		}
		else
		{
			System.out.println(" You are not  for LLR Test:" +date);

		}
	}
	
}
