package DEMO;

public class DataTypes 
{
int a= 1;
byte b= -128;
short c= -32768;
long d= 9223372036854775807l;
double e=0.0;
boolean f= false;
float g= 0.0f;
char h='M';

public static void main(String []args)
{
	DataTypes y = new DataTypes();
    System.out.println(y.a);
    System.out.println(y.b);
    System.out.println(y.c);
    System.out.println(y.d);
    System.out.println(y.e);
    System.out.println(y.f);
    System.out.println(y.g);
    System.out.println(y.h);

}

}
