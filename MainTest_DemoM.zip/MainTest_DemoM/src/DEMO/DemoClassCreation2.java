package DEMO;

public class DemoClassCreation2 
{
public void test2()
{
	System.out.println("Class creation2 retriving");
}

}
