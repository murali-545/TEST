package JumpingStatements;

public class Demo1 
{
	public static String[] testr()
	 {
		String fruits[]={"Apple","Banana","Guva","Mango"}; //Skipping Banana
		return fruits;
	 }	

	public static void main(String[] args) 
	{
	 
		//String fruits[]={"Apple","Banana","Guva","Mango"}; //Skipping Banana
		//continue Program
		for (String singlefruit : testr()) 
		{
			if(singlefruit=="Banana") // if(singlefruit=="Banana" || singlefruit=="Guva") two fruits skipping
			{
				continue;
			}
			System.out.println(singlefruit);
		}
		//System.exit(0);
		for (String singlefruit : testr())  //Banana vastey terminate aiepo
		{
			if(singlefruit=="Banana") // if(singlefruit=="Banana" || singlefruit=="Guva") two fruits skipping
			{
				System.exit(0);
			}
			System.out.println(singlefruit);

		 
	}
		
//		for (String singlefruit : testr())  //Banana vastey terminate aiepo
//		{
//			if(singlefruit=="Banana") // if(singlefruit=="Banana" || singlefruit=="Guva") two fruits skipping
//			{
//				break;
//			}
//			System.out.println(singlefruit);
//
//		 
//	}

			}
 
}
