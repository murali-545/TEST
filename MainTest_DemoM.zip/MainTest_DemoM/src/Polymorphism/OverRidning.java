package Polymorphism;


//Runtime Polymorphisam
public class OverRidning extends Overloading
{
	@Override
	public void method1() 
	{
		
		System.out.println("Over riding method");
		
	}
	@Override
	public void method1(int a) 
	{
		System.out.println(a);	
	}
	
	@Override
	public void method1(int b, long l) 
	{
		System.out.println(b+","+l);
	}
	public static void main(String[] args) 
	{
		OverRidning or = new OverRidning();
		or.method1();
		or.method1(9);
		or.method1(8, 7l);
		
	}

}