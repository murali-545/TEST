package Polymorphism;

public class Overloading //compile time polymorphism
//Same method name with different arguments--Complie Time
{
public void method1()
{
	System.out.println("method 1 without argument");
}
public void method1(int a)
{
	System.out.println("method 1 with argument :" +a);

}
public void method1(int b,long l)
{
	System.out.println("method 1 with argument:" +b +","+l );

}
public static void main(String[] args) 
{
	Overloading op =new Overloading();
	op.method1();
	op.method1(4);
	op.method1(5, 6l);
}
}
